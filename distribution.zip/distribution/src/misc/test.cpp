class foo {foo() {}};
